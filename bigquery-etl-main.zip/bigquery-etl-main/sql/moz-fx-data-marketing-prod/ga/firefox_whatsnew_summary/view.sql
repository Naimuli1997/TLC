CREATE OR REPLACE VIEW
  `moz-fx-data-marketing-prod.ga.firefox_whatsnew_summary`
AS
SELECT
  *
FROM
  `moz-fx-data-marketing-prod.ga_derived.firefox_whatsnew_summary_v2`
