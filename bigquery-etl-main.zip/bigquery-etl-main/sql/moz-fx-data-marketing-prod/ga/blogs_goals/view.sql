CREATE OR REPLACE VIEW
  `moz-fx-data-marketing-prod.ga.blogs_goals`
AS
SELECT
  *
FROM
  `moz-fx-data-marketing-prod.ga_derived.blogs_goals_v2`
