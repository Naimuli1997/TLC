CREATE OR REPLACE VIEW
  `moz-fx-data-marketing-prod.ga.blogs_daily_summary`
AS
SELECT
  *
FROM
  `moz-fx-data-marketing-prod.ga_derived.blogs_daily_summary_v2`
