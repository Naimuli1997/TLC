CREATE OR REPLACE VIEW
  `moz-fx-data-marketing-prod.ga.blogs_sessions`
AS
SELECT
  *
FROM
  `moz-fx-data-marketing-prod.ga_derived.blogs_sessions_v2`
