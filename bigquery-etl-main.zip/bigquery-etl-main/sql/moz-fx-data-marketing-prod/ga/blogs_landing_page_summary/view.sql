CREATE OR REPLACE VIEW
  `moz-fx-data-marketing-prod.ga.blogs_landing_page_summary`
AS
SELECT
  *
FROM
  `moz-fx-data-marketing-prod.ga_derived.blogs_landing_page_summary_v2`
