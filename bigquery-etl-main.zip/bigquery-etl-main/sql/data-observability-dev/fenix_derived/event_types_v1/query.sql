SELECT
  *
FROM
  `moz-fx-data-shared-prod.fenix_derived.event_types_v1`
