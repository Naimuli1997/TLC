CREATE OR REPLACE VIEW
  `data-observability-dev.fenix.event_types`
AS
SELECT
  *
FROM
  `data-observability-dev.fenix_derived.event_types_v1`
