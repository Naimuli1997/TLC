CREATE OR REPLACE VIEW
  `data-observability-dev.fenix.firefox_android_anonymised`
AS
SELECT
  *
FROM
  `data-observability-dev.fenix_derived.firefox_android_anonymised_v1`
