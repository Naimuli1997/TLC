CREATE OR REPLACE VIEW
  `data-observability-dev.fenix.firefox_android_aggregates`
AS
SELECT
  *
FROM
  `data-observability-dev.fenix_derived.firefox_android_aggregates_v1`
