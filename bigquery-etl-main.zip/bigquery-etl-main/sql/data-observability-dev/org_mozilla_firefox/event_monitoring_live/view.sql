CREATE OR REPLACE VIEW
  `data-observability-dev.org_mozilla_firefox.event_monitoring_live`
AS
SELECT
  *
FROM
  `data-observability-dev.org_mozilla_firefox_derived.event_monitoring_live_v1`
