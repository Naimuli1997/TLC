SELECT
  *
FROM
  `moz-fx-data-shared-prod.telemetry.latest_versions`
