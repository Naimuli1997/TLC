# Remove data collected during hotfix rollout from GCP

See [bug 1550814](https://bugzilla.mozilla.org/show_bug.cgi?id=1550814).
