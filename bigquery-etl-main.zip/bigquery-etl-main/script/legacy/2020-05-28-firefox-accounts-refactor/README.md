See https://github.com/mozilla/bigquery-etl/pull/1015
