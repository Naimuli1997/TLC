"""Provides bigquery-etl version information."""

__version__ = "20.12.2"
